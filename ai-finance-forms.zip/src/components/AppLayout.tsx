import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { useIsMobile } from '@/hooks/use-mobile';
import Sidebar from '@/components/Sidebar';
import DashboardContent from '@/components/dashboard/DashboardContent';

const AppLayout: React.FC = () => {
  const { sidebarOpen, toggleSidebar } = useAppContext();
  const isMobile = useIsMobile();

  return (
    <div className="flex h-screen bg-slate-100 dark:bg-slate-950">
      <Sidebar isOpen={sidebarOpen} onToggle={toggleSidebar} isMobile={isMobile} />
      
      <main className={`flex-1 overflow-auto transition-all duration-300 ${sidebarOpen && !isMobile ? 'ml-64' : isMobile ? '': 'ml-20'}`}>
        <DashboardContent />
      </main>
    </div>
  );
};

export default AppLayout;