import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const Logo: React.FC<LogoProps> = ({ className = '', size = 'md' }) => {
  const sizeClasses = {
    sm: 'h-6 w-6',
    md: 'h-8 w-8',
    lg: 'h-12 w-12'
  };

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <img 
        src="https://d64gsuwffb70l.cloudfront.net/6826e31ac043c382baa7c381_1747388467358_19099628.png" 
        alt="CV Logo" 
        className={`${sizeClasses[size]} object-contain`} 
      />
      <span className="font-bold text-xl">BusinessCRM</span>
    </div>
  );
};

export default Logo;