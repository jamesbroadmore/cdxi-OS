import React from 'react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import Logo from '@/components/Logo';
import {
  LayoutDashboard,
  Users,
  FileText,
  DollarSign,
  Mail,
  FileSignature,
  Settings,
  Menu,
  X
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  isMobile: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onToggle, isMobile }) => {
  const navItems = [
    { icon: <LayoutDashboard size={20} />, label: 'Dashboard', href: '#' },
    { icon: <Users size={20} />, label: 'Customers', href: '#' },
    { icon: <FileText size={20} />, label: 'Invoices', href: '#' },
    { icon: <DollarSign size={20} />, label: 'Finances', href: '#' },
    { icon: <Mail size={20} />, label: 'Email Templates', href: '#' },
    { icon: <FileSignature size={20} />, label: 'Business Forms', href: '#' },
    { icon: <Settings size={20} />, label: 'Settings', href: '#' },
  ];

  if (isMobile && !isOpen) return null;

  return (
    <aside 
      className={`bg-slate-50 dark:bg-slate-900 h-screen flex flex-col border-r transition-all duration-300 ${isOpen ? 'w-64' : 'w-20'} ${isMobile ? 'fixed z-50 left-0 top-0' : ''}`}
    >
      <div className="p-4 flex items-center justify-between border-b">
        {isOpen ? (
          <Logo size="sm" />
        ) : (
          <div className="w-full flex justify-center">
            <Logo size="sm" className="flex-col items-center" />
          </div>
        )}
        <Button variant="ghost" size="icon" onClick={onToggle} className="ml-auto">
          {isMobile ? <X size={20} /> : (isOpen ? <Menu size={20} /> : <Menu size={20} />)}
        </Button>
      </div>
      
      <ScrollArea className="flex-1">
        <nav className="px-2 py-4">
          <ul className="space-y-2">
            {navItems.map((item, index) => (
              <li key={index}>
                <a 
                  href={item.href}
                  className="flex items-center p-2 rounded-md hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
                >
                  <span className="text-slate-600 dark:text-slate-300">{item.icon}</span>
                  {isOpen && <span className="ml-3 text-sm font-medium">{item.label}</span>}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </ScrollArea>
    </aside>
  );
};

export default Sidebar;