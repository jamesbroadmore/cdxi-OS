import React, { createContext, useContext, useState } from 'react';
import { customers, products, invoices, transactions, emailTemplates, businessForms } from '@/data/mockData';

interface AppContextType {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  customers: typeof customers;
  products: typeof products;
  invoices: typeof invoices;
  transactions: typeof transactions;
  emailTemplates: typeof emailTemplates;
  businessForms: typeof businessForms;
}

const defaultAppContext: AppContextType = {
  sidebarOpen: false,
  toggleSidebar: () => {},
  customers,
  products,
  invoices,
  transactions,
  emailTemplates,
  businessForms
};

const AppContext = createContext<AppContextType>(defaultAppContext);

export const useAppContext = () => useContext(AppContext);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(prev => !prev);
  };

  return (
    <AppContext.Provider
      value={{
        sidebarOpen,
        toggleSidebar,
        customers,
        products,
        invoices,
        transactions,
        emailTemplates,
        businessForms
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
