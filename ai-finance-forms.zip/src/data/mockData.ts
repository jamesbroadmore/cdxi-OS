import { Customer, Product, Invoice, Transaction, EmailTemplate, BusinessForm } from '@/types';
import { v4 as uuidv4 } from 'uuid';

// Mock Customers
export const customers: Customer[] = [
  {
    id: uuidv4(),
    name: 'John Smith',
    email: 'john@example.com',
    phone: '555-123-4567',
    address: '123 Main St, Anytown, USA',
    company: 'ABC Corp'
  },
  {
    id: uuidv4(),
    name: 'Jane Doe',
    email: 'jane@example.com',
    phone: '555-987-6543',
    address: '456 Oak Ave, Somewhere, USA',
    company: 'XYZ Inc'
  },
];

// Mock Products
export const products: Product[] = [
  {
    id: uuidv4(),
    name: 'Consulting Service',
    description: 'Professional business consulting',
    price: 150,
    unit: 'hour'
  },
  {
    id: uuidv4(),
    name: 'Website Development',
    description: 'Custom website creation',
    price: 2500,
    unit: 'project'
  },
];

// Mock Invoices
export const invoices: Invoice[] = [
  {
    id: uuidv4(),
    customerId: customers[0].id,
    date: '2023-09-01',
    dueDate: '2023-09-15',
    items: [
      {
        id: uuidv4(),
        productId: products[0].id,
        description: 'Business strategy consulting',
        quantity: 10,
        unitPrice: 150,
        total: 1500
      }
    ],
    subtotal: 1500,
    tax: 150,
    total: 1650,
    status: 'paid',
    notes: 'Thank you for your business!'
  },
];

// Mock Transactions
export const transactions: Transaction[] = [
  {
    id: uuidv4(),
    date: '2023-09-15',
    description: 'Payment for Invoice #1',
    amount: 1650,
    type: 'income',
    category: 'Consulting',
    invoiceId: invoices[0].id
  },
  {
    id: uuidv4(),
    date: '2023-09-05',
    description: 'Office supplies',
    amount: 125.50,
    type: 'expense',
    category: 'Office'
  },
];

// Mock Email Templates
export const emailTemplates: EmailTemplate[] = [
  {
    id: uuidv4(),
    name: 'Invoice Reminder',
    subject: 'Reminder: Invoice #{invoiceNumber} Due Soon',
    content: 'Dear {customerName},\n\nThis is a friendly reminder that invoice #{invoiceNumber} for ${amount} is due on {dueDate}.\n\nThank you for your business!\n\nRegards,\nYour Business'
  },
];

// Mock Business Forms
export const businessForms: BusinessForm[] = [
  {
    id: uuidv4(),
    name: 'Client Intake Form',
    content: 'Please provide the following information to get started:',
    fields: ['Full Name', 'Email', 'Phone', 'Company', 'Project Description']
  },
];